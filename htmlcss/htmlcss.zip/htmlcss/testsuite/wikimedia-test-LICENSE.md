Wikimedia Test.svg
==================

https://commons.wikimedia.org/wiki/File:Test.svg

This file is licensed under the Creative Commons Attribution-Share Alike 3.0
Unported license.
