SVG 1.1 Second Edition Test Suite: 16 August 2011
=================================================

https://www.w3.org/Graphics/SVG/WG/wiki/Test_Suite_Overview

The 16 August 2011 release of the SVG 1.1 Second Edition Test Suite includes a
total of 445 tests, most with numerous subtests.
