SVG File Icons
==============

https://fileicons.org

All icons used in the creation of this library were licensed MIT, Creative Commons or purchased royalty-free. Any exceptions have attribution. All logos are copyright their respective owners.

